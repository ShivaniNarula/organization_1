/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookboon.jasper;

import java.util.Date;

/**
 *
 * @author Ankush
 */
public class JavaPojo {
    
    private String OrganizationName;
    private String User;
    private String Country;
    private String Type;
    private int Value;
    private Date Added;
    private Date Scheduled;
    private int MeetingWithinTwoWeeks;
    private int MeetingsWithinThreeMonths;
    private String Tags;
    
    public String getOrganizationName() {
        return OrganizationName;
    }

    public void setOrganizationName(String OrganizationName) {
        this.OrganizationName = OrganizationName;
    }

    public String getUser() {
        return User;
    }

    public void setUser(String User) {
        this.User = User;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public int getValue() {
        return Value;
    }

    public void setValue(int Value) {
        this.Value = Value;
    }

    public Date getAdded() {
        return Added;
    }

    public void setAdded(Date Added) {
        this.Added = Added;
    }

    public Date getScheduled() {
        return Scheduled;
    }

    public void setScheduled(Date Scheduled) {
        this.Scheduled = Scheduled;
    }

    public int getMeetingWithinTwoWeeks() {
        return MeetingWithinTwoWeeks;
    }

    public void setMeetingWithinTwoWeeks(int MeetingWithinTwoWeeks) {
        this.MeetingWithinTwoWeeks = MeetingWithinTwoWeeks;
    }

    public int getMeetingsWithinThreeMonths() {
        return MeetingsWithinThreeMonths;
    }

    public void setMeetingsWithinThreeMonths(int MeetingsWithinThreeMonths) {
        this.MeetingsWithinThreeMonths = MeetingsWithinThreeMonths;
    }

    public String getTags() {
        return Tags;
    }

    public void setTags(String Tags) {
        this.Tags = Tags;
    }

    @Override
    public String toString() {
        return OrganizationName+" ,"
                +User+" ,"
                +Country+" ,"
                +Type+" ," 
                +Value+" ,"
                + Added+" ,"
                +Scheduled+" ,"
                +MeetingWithinTwoWeeks+ " ,"
                +MeetingsWithinThreeMonths+ " ,"
                +Tags
                
                ; //To change body of generated methods, choose Tools | Templates.
    }
    
}
