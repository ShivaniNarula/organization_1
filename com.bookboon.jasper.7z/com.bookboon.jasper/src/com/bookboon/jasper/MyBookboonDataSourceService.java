/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookboon.jasper;
import java.util.Map;
 
import net.sf.jasperreports.engine.JRDataSource;
 
import com.jaspersoft.jasperserver.api.metadata.common.service.RepositoryService;
import com.jaspersoft.jasperserver.api.metadata.jasperreports.service.ReportDataSourceService;
import java.util.Map;

/**
 *
 * @author User1
 */
public class MyBookboonDataSourceService implements ReportDataSourceService{
JRDataSource jrds;
    private RepositoryService repository;
    private Map propertyMap;
   
    public MyBookboonDataSourceService() {
        jrds = new MyBookboonDataSource();
    }
    public MyBookboonDataSourceService(JRDataSource ds) {
        //this.jrds = ds;
    }
    @Override
    public void setReportParameterValues(Map map) {
//        for (Object obj : parameterValues.entrySet()) {
//            logger.debug("Parameter "+obj.toString());
//        }
//        jrds = new TestDataSource((java.sql.Date) parameterValues.get("PeriodEndDate"));
//        parameterValues.put(JRParameter.REPORT_DATA_SOURCE, jrds);
   }

    @Override
    public void closeConnection() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     public Map getPropertyMap() {
        return propertyMap;
    }
 
    public void setPropertyMap(Map propertyMap) {
        this.propertyMap = propertyMap;
    }
 
    public RepositoryService getRepository() {
    return repository;
    }
    
}
