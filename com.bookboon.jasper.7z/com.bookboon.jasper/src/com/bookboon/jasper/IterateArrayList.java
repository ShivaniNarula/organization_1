/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookboon.jasper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Ankush
 */
public class IterateArrayList {
    
    public static String User;
    public static String Country;
    public static String OrganizationName;
    public static String Tags;
    public static String Type;
    public static Date Added;
    public static Date Scheduled;
    public static int Value;
    public static int MeetingWithinTwoWeeks;
    public static int MeetingsWithinThreeMonths;
    
    
    public static void itre() throws ParseException
    {
    ArrayList<JavaPojo> ab=BeanParseCSV.parseCsv();
    int size=ab.size();
    for(int i=0;i<size;i++)
    {
        User=ab.get(i).getUser();
        Country=ab.get(i).getCountry();
        OrganizationName=ab.get(i).getOrganizationName();
        Tags=ab.get(i).getTags();
        Type=ab.get(i).getType();
        Added=ab.get(i).getAdded();
        Scheduled=ab.get(i).getScheduled();
        Value=ab.get(i).getValue();
        MeetingWithinTwoWeeks=ab.get(i).getMeetingWithinTwoWeeks();
        MeetingsWithinThreeMonths=ab.get(i).getMeetingsWithinThreeMonths();
        System.out.println(User+"-----"+Country);
    }
  
            
            }
}
