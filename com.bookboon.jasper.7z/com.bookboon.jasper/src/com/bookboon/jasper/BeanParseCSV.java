/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookboon.jasper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author Ankush
 */
public class BeanParseCSV {
    
    public static ArrayList<JavaPojo> parseCsv() throws ParseException
    {
         String csvFile = "resource/sales-funnel.csv";
        String line = "";
        String cvsSplitBy = ",";
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        ArrayList<JavaPojo> myarray = new ArrayList<JavaPojo>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            while ((line = br.readLine()) != null) {   
                // use comma as separator
                JavaPojo myobject = new JavaPojo();
                String[] country = line.split(cvsSplitBy);
                myobject.setOrganizationName(country[0]);
                myobject.setUser(country[1]);
                myobject.setCountry(country[2]);
                myobject.setType(country[3]);
                myobject.setValue(Integer.parseInt(country[4]));
                myobject.setAdded(formatter.parse(country[5]));
                myobject.setScheduled(formatter.parse(country[6]));
                myobject.setMeetingWithinTwoWeeks(Integer.parseInt(country[7]));
                myobject.setMeetingsWithinThreeMonths(Integer.parseInt(country[8]));
                myobject.setTags(country[9]);
                //System.out.println(myobject.getUser()+myobject.getCountry()); 
                myarray.add(myobject);
                
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return myarray;
    }
    
}
