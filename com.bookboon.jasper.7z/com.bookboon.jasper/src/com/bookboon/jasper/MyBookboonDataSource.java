/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookboon.jasper;

import com.jaspersoft.jasperserver.api.metadata.jasperreports.domain.ReportDataSource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;


/**
 *
 * @author User1
 */

public class MyBookboonDataSource implements JRDataSource {
    
    
    ArrayList myarray;
   /**
	 * Variable to store how much records were read
	 */
	private int counter = -1;
	
	/**
	 * Variables to store the number of fields, and their names, in the report
	 */
	private HashMap<String, Integer> fieldsNumber = new HashMap<String, Integer>();
	
	/**
	 * Method used to know if there are records to read.
	 */
	private int lastFieldsAdded = 0;
ArrayList<JavaPojo> ab;


   

    @Override
    public boolean next() throws JRException {
        try {
            myarray=BeanParseCSV.parseCsv();
        } catch (ParseException ex) {
            Logger.getLogger(MyBookboonDataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
       if (counter<myarray.size()) {
			counter++;
			return true;
		}
		return false;
    }

    @Override
    public Object getFieldValue(JRField jrField) throws JRException {
        Integer fieldIndex;
        try {
            ab = BeanParseCSV.parseCsv();
        } catch (ParseException ex) {
            Logger.getLogger(MyBookboonDataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
		if (fieldsNumber.containsKey(jrField.getName()))
			fieldIndex = fieldsNumber.get(jrField.getName());
		else {
			fieldsNumber.put(jrField.getName(), lastFieldsAdded);
			fieldIndex = lastFieldsAdded;
			lastFieldsAdded ++;
		}
		if (fieldIndex == 0) return ab.get(counter).getOrganizationName(); 
		else if (fieldIndex == 1) return ab.get(counter).getUser();
                else if (fieldIndex == 2) return ab.get(counter).getCountry();
                else if (fieldIndex == 3) return ab.get(counter).getType();
                else if (fieldIndex == 4) return ab.get(counter).getValue();
                else if (fieldIndex == 5) return ab.get(counter).getAdded();
                else if (fieldIndex == 6) return ab.get(counter).getScheduled();
                else if (fieldIndex == 7) return ab.get(counter).getMeetingWithinTwoWeeks();
                else if (fieldIndex == 8) return ab.get(counter).getMeetingsWithinThreeMonths();
                else if (fieldIndex == 9) return ab.get(counter).getTags();
		return "";
               
    }
  public static JRDataSource getDataSource(){
		return new MyBookboonDataSource();
	}  
}
