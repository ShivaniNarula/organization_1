/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bookboon.jasper;

import com.jaspersoft.jasperserver.api.metadata.jasperreports.domain.ReportDataSource;
import com.jaspersoft.jasperserver.api.metadata.jasperreports.service.ReportDataSourceService;
import com.jaspersoft.jasperserver.api.metadata.jasperreports.service.ReportDataSourceServiceFactory;

/**
 *
 * @author User1
 */
public class MyBookboonDataSourceServiceFactory implements ReportDataSourceServiceFactory {
 public MyBookboonDataSourceServiceFactory() { }
 
    public MyBookboonDataSourceService createDataSourceService() {
        return new MyBookboonDataSourceService();
    }
    @Override
    public ReportDataSourceService createService(ReportDataSource rds) {
         return new MyBookboonDataSourceService();
    }
    
}
